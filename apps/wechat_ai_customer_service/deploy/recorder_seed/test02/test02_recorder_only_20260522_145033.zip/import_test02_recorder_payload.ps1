param(
  [string]$WorkspaceRoot = "D:\AI\omniauto"
)

$ErrorActionPreference = "Stop"
$pkgRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$payloadTenantRoot = Join-Path $pkgRoot "payload\runtime\tenants\test02"
if (!(Test-Path $payloadTenantRoot)) {
  throw "Payload not found: $payloadTenantRoot"
}

$targetTenantRoot = Join-Path $WorkspaceRoot "runtime\apps\wechat_ai_customer_service\tenants\test02"
$backupRoot = Join-Path $WorkspaceRoot "runtime\apps\wechat_ai_customer_service\migration_import_backups"
New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
if (Test-Path $targetTenantRoot) {
  $backupZip = Join-Path $backupRoot "test02_before_import_$ts.zip"
  Compress-Archive -Path (Join-Path $targetTenantRoot "*") -DestinationPath $backupZip -Force
  Write-Host "Backed up existing tenant folder to: $backupZip"
} else {
  New-Item -ItemType Directory -Force -Path $targetTenantRoot | Out-Null
}

Copy-Item -Path (Join-Path $payloadTenantRoot "*") -Destination $targetTenantRoot -Recurse -Force
Write-Host "Imported payload to: $targetTenantRoot"
Write-Host "Done. Please restart admin backend + worker processes."
