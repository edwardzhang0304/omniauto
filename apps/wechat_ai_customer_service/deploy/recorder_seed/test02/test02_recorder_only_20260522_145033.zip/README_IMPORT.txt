test02 AI Recorder migration package

Safe import scope: payload/runtime/tenants/test02/* only
Do NOT overwrite global files unless you explicitly want to replace global module config.

Import steps on target machine:
1) Stop admin_backend and background workers.
2) Backup target folder runtime/apps/wechat_ai_customer_service/tenants/test02/
3) Copy payload/runtime/tenants/test02/* into runtime/apps/wechat_ai_customer_service/tenants/test02/
4) Start services and log in as test02, then verify Recorder conversation/message counts.
5) If needed, manually rebind recorder module in UI/API (avoid global overwrite).
Optional historical data:
- optional_reference/historical/test02_rag_experience/experiences.json
  This is a historical snapshot, import only if you explicitly want old RAG experience records.
